import math


class ComputeChange:

    def __init__(self, valtosub):
        self.valtosub = valtosub

    def changevalue(self):
        return math.ceil(math.exp(self.valtosub) - 10)
