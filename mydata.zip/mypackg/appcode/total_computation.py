from mypackg.appcode.compute import ComputeChange
from mypackg.dbutils.dbops import Datamake


class GetReady:

    def __init__(self):
        # self.drinks_df = pd.read_csv('https://raw.githubusercontent.com/justmarkham/pandas-videos/master/data/drinks.csv', header=0)
        self.con = Datamake()


class Operation(GetReady):

    def __init__(self, tbl_name):
        super().__init__()

        self.table_name = tbl_name
        self.table = self.con.read("select * from {}".format(self.table_name))
        print(f"current data is:\n {self.table}")

    def final_method(self, myval):
        """"
        change the column id with the given a computation (padd with given value)
        """
        changeobj = ComputeChange(myval)
        # assign new column to the dataframe and call it newdf
        newdf = self.table.assign(newid=str(myval) + self.table['id'] + str(changeobj.changevalue()))
        newdf.drop(['id'], axis=1, inplace=True)
        newdf.rename(columns={'newid': 'id'}, inplace=True)
        #return newdf
        self.con.write(newdf, tbl_name=self.table_name)
        print(" \nnew data is:")
        return self.con.read(f"select * from {self.table_name}")
