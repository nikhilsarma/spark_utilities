import pandas as pd
from sqlalchemy import create_engine

mysql_databases ={'recom':'recommendation_spark','sales':'sales_db_nik'}
#sqlite_PATH = os.path.join(os.path.dirname(__file__), 'database.sqlite3')


class DummyDataMake:

    def __init__(self):
        self.engine = create_engine('sqlite://') #creates an inmem database

    def create_tables(self, cur):
            # con = db_connect() # connect to the database
            # cur = con.cursor() # instantiate a cursor obj
            heros_sql = """
          CREATE TABLE heros (
              id text NOT NULL,
             first_name text NOT NULL,
              last_name text NOT NULL)"""
            cur.execute(heros_sql)
            powers_sql = """
          CREATE TABLE powers (
              id text NOT NULL,
              name text NOT NULL,
            intensity real NOT NULL)"""
            cur.execute(powers_sql)

    def put_dummy_data(self, cur):
            powers_sql = "INSERT INTO powers (id, name, intensity) VALUES (?,?,?)"
            cur.execute(powers_sql, (1, 'super speed', 10))
            cur.execute(powers_sql, (2, 'shapeshifting', 5))
            cur.execute(powers_sql, (3, 'super sense', 15))
            cur.execute(powers_sql, (4, 'invisibility', 30))

            heros_sql = "INSERT INTO heros (id, first_name, last_name) VALUES (?, ?, ?)"
            cur.execute(heros_sql, (1, 'spider', 'man'))
            cur.execute(heros_sql, (2, 'super', 'man'))
            cur.execute(heros_sql, (3, 'hit', 'man'))
            cur.execute(heros_sql, (4, 'he', 'man'))


class Datamake(DummyDataMake):
    def __init__(self, dbname=None):
        super().__init__()
        #self.engine = create_engine('mysql+pymysql://root:123456@localhost/{}'.format(dbname))
        #self.engine = create_engine('sqlite://')
        self.dbname = dbname #not useful since we created an inmemory database
        super().create_tables(self.engine)
        super().put_dummy_data(self.engine)

    def read(self, query):

        res = self.engine.execute(query)
        table_cols = res.keys()
        table_data = res.fetchall()
        df = pd.DataFrame(table_data, columns=table_cols)
        return df

    def write(self, df, tbl_name=None):
        df.to_sql(con=self.engine, name=tbl_name, if_exists='append', index=False)
        print(f"\nsuccessfully written {len(df)} new records to {tbl_name}")


ob = Datamake()
re = ob.read("select * from heros")


