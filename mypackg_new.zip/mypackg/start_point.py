
from mypackg.appcode.total_computation import Operation
import csv

def main(args):

    mainobj = Operation(args[0])
    result = mainobj.final_method(args[1])
    return result

#main(table='heros', val=1)



